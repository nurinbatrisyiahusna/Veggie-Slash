#include <graphics.h>
#include <ctime>
#include <vector>
using namespace std;

#include "gameObject/bomb/bomb.hpp"
#include "gameObject/rock/rock.hpp"
#include "gameObject/veggie/veggie.hpp"

#include "icon/cross/cross.hpp"
#include "icon/score/score.hpp"
#include "icon/timer/timer.hpp"

#include "player/player.hpp"

int main(){
    int width = getmaxwidth();
    int height = getmaxheight();
    initwindow( width, height, "Veggie Slash");

    setbkcolor(GREEN);
    cleardevice();  //clear screen with WHITE (fill the whole screen)

    settextstyle(TRIPLEX_FONT, HORIZ_DIR, 5);
    setcolor(WHITE);
    outtextxy(width/3, height/3, "VEGGIE SLASH");


    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    setcolor(BLACK);
    outtextxy(width/2.5, height/2, "Press ENTER to Start");
    getch();


    //if(ismouseclick(WM_))

    return 0;
}