#include "score.hpp"
#include "../score/score.hpp"
#include <graphics.h>

Score::Score() : Icon(0, 0, 50, 50) {}

Score::Score(int x, int y, int width, int height){
    this-> x=x;
    this-> y=y;
    this-> width=width;
    this-> height=height;
}

Score::~Score(){}

int Score::getX() const {return x;}
int Score::getY() const {return y;}
int Score::getWidth() const {return width;}
int Score::getHeight() const {return height;}

void Score::setPosition(int x, int y){
    this-> x=x;
    this-> y=y;
}

void Score::draw(){ 
    readimagefile("images/cabbage.png", x, y, x + width, y + height);
    outtextxy (x + 60, y + 10, "Score");
}