#ifndef SCORE
#define SCORE

#include "../icon.hpp"

class Score : public Icon{
private:
    int x, y;
    int width, height;

public:
    Score();
    Score(int x, int y, int width, int height);  //position
    ~Score();

    //getter
    int getX() const;
    int getY() const;
    int getWidth() const;
    int getHeight() const;

    //setter
    void setPosition(int x, int y);

    void draw();
};
#endif