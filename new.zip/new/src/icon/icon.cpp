#include "icon.hpp"

Icon::Icon() {
    x = 0;
    y = 0;
    width = 50;
    height = 50;
}

Icon::Icon(int x, int y, int width, int height){
    this-> x=x;
    this-> y=y;
    this-> width=width;
    this-> height=height;
}

Icon::~Icon(){}

int Icon::getX() const {return x;}
int Icon::getY() const {return y;}
int Icon::getWidth() const {return width;}
int Icon::getHeight() const {return height;}


void Icon::setPosition(int x, int y){
    this-> x=x;
    this-> y=y;
}

void Icon::draw(){}
