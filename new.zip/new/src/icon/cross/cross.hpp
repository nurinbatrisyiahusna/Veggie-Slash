#ifndef CROSS
#define CROSS

#include "../icon.hpp"

class Cross : public Icon {
private:
    int x, y;
    int width, height;

public:
    Cross();
    Cross(int x, int y, int width, int height);  //position
    ~Cross();

    //getter
    int getX() const;
    int getY() const;
    int getWidth() const;
    int getHeight() const;

    //setter
    void setPosition(int x, int y);

    void draw();

    
};
#endif