#include "cross.hpp"
#include "../cross/cross.hpp"
#include <graphics.h>

Cross::Cross() : Icon(0, 0, 50, 50) {}

Cross::Cross(int x, int y, int width, int height){
    this-> x=x;
    this-> y=y;
    this-> width=width;
    this-> height=height;
}

Cross::~Cross(){}

int Cross::getX() const {return x;}
int Cross::getY() const {return y;}
int Cross::getWidth() const {return width;}
int Cross::getHeight() const {return height;}

void Cross::setPosition(int x, int y){
    this-> x=x;
    this-> y=y;
}

void Cross::draw(){
    int rightX = 750;

    for (int i=0; i<3; i++){
        readimagefile("images/cross.png", 
                        rightX + i *30,                 // dont want X(s) overlap       //*30 (spacing)
                        y,                              // fix y (same line)
                        rightX + i * 30 + width,        // how wide the image is
                        y + height);                    // ""
        
    }
}