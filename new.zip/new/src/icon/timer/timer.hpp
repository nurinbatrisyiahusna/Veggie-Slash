#ifndef TIMER
#define TIMER

#include "../icon.hpp"

class Timer : public Icon {
    private: 
        int startTime; //when the game starts
        int duration;
        int x, y;

    public:
        Timer();

        void start();             //set start time
        int getTimeLeft() const;  //calculate remaining time

        void draw() const;

};

#endif