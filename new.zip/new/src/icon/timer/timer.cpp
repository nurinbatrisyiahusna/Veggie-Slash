#include "timer.hpp"
#include "../timer/timer.hpp"
#include <ctime>
#include <graphics.h>
#include<string>

Timer::Timer() {
    startTime = 0;
    duration = 30;
}

void Timer::start() {
    startTime = time(NULL);
}

int Timer::getTimeLeft() const {
    int elapsed = time(NULL) - startTime;
    int left = duration - elapsed;

    if (left < 0) return 0; //prevent negative time
    return left;
}

void Timer::draw() const {
    int timeLeft = getTimeLeft();
    int centreX = 400;      //centre of the screen
    outtextxy (centreX + 60, y + 10, "Timer");
}
