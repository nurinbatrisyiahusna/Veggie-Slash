#ifndef ICON
#define ICON

class Icon{
private:
    int x, y;
    int width, height;

public:
    Icon();
    Icon(int x, int y, int width, int height);  //position
    ~Icon();

    //getter
    int getX() const;
    int getY() const;
    int getWidth() const;
    int getHeight() const;

    //setter
    void setPosition(int x, int y);

    void draw();
};
#endif