//represent object (veg, rock, bomb)
//sabtu

#ifndef GAMEOBJECT
#define GAMEOBJECT
#include <ctime>

class GameObject{
private:
    int x, y;               //position //comppotio
    int width, height;      //size
    time_t spawnTime;

public:
    GameObject();
    GameObject(int x, int y, int width, int height);
    ~GameObject();

    //getter
    int getX() const;
    int getY() const;
    int getWidth() const;
    int getHeight() const;

    //setter
    void setX(int x);
    void setY(int y);
    void setPosition(int x, int y);

    void draw();    
    void undraw();

    bool isHit(int mouseX, int mouseY) const;   //mouse click (collision)
};

#endif