#ifndef BOMB    
#define BOMB

#include "../gameObject.hpp"
#include <string>

//inheritance
class Bomb : public GameObject{
private:

public:
    Bomb();
    Bomb(int x, int y);   //position
    
    void draw(); //show correct png
    bool isHit(int mouseX, int mouseY) const; 

};
#endif