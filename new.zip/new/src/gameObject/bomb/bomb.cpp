#include "bomb.hpp"
#include "../bomb/bomb.hpp"
#include<graphics.h>

Bomb::Bomb() : GameObject(0, 0, 50, 50) {}

Bomb::Bomb(int x, int y) : GameObject(x, y, 50, 50) {}

void Bomb::draw()
{
    readimagefile("images/bomb.png",
                    getX(),
                    getY(),
                    getX() + getWidth(),
                    getY() + getHeight()
                );
}

bool Bomb::isHit(int mouseX, int mouseY) const{
    return GameObject::isHit(mouseX, mouseY);
}