#include "rock.hpp"
#include "../rock/rock.hpp"
#include<graphics.h>

Rock::Rock() : GameObject(0, 0, 50, 50) {}

Rock::Rock(int x, int y) : GameObject(x, y, 50, 50) {}

void Rock::draw()
{
    readimagefile("images/rock.png",
                    getX(),
                    getY(),
                    getX() + getWidth(),
                    getY() + getHeight()
                );
}

bool Rock::isHit(int mouseX, int mouseY) const{
    return GameObject::isHit(mouseX, mouseY);
}