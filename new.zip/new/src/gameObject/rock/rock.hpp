#ifndef ROCK    
#define ROCK

#include "../gameObject.hpp"
#include <string>

//inheritance
class Rock : public GameObject{
private:

public:
    Rock();
    Rock(int x, int y);   //position
    
    void draw(); //show correct png
    bool isHit(int mouseX, int mouseY) const; 

};
#endif