#include "veggie.hpp"
#include "../veggie/veggie.hpp"
#include <graphics.h>
#include <string>

Veggie::Veggie(): GameObject(0, 0, 50, 50) { //parent constructor
    type = "carrot", "tomato", "cabbage";
}

Veggie::Veggie(int x, int y, std::string type) : GameObject (x, y, 50, 50) {
    this->type = type;
}   //position

//getter
std::string Veggie::getType() const {return type;}

//show correct png
void Veggie::draw()
{
    if (type == "carrot") {
        readimagefile("images/carrot.jpg",
                        getX(),
                        getY(),
                        getX() + getWidth(),
                        getY() + getHeight()
                    );
    }
    else if (type == "tomato")
    {
        readimagefile("images/tomato.jpg",
                        getX(),
                        getY(),
                        getX() + getWidth(),
                        getY() + getHeight()
                    );
    }
    else if (type == "cabbage")
    {
        readimagefile("images/cabbage.jpg",
                        getX(),
                        getY(),
                        getX() + getWidth(),
                        getY() + getHeight()
                    );
    }
} 

//reuse parent's collision detection
bool Veggie::isHit(int mouseX, int mouseY) const{
    return GameObject::isHit(mouseX, mouseY);
}