#ifndef VEGGIE
#define VEGGIE

#include "../gameObject.hpp"
#include <string>

//inheritance
class Veggie : public GameObject{
private:
    std::string type; //what kind of veggie is this (identify)

public:
    Veggie();
    Veggie(int x, int y, std::string type);   //position

    //getter
    std::string getType() const;
    
    void draw(); //show correct png
    bool isHit(int mouseX, int mouseY) const; 

};
#endif