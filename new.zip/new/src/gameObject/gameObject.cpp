#include "gameObject.hpp"

GameObject::GameObject(){
    x=0;
    y=0;
    width=50;
    height=50;
    spawnTime=time(NULL);
}

GameObject::GameObject(int x, int y, int width, int height){
    this-> x=x;
    this-> y=y;
    this-> width=width;
    this-> height=height;
    spawnTime=time(NULL);
}

GameObject::~GameObject(){}


int GameObject::getX() const {return x;}
int GameObject::getY() const {return y;}
int GameObject::getWidth() const {return width;}
int GameObject::getHeight() const {return height;}

void GameObject::draw(){
    //tulis kat child
    //overides
}   

void GameObject::undraw(){}

bool GameObject::isHit(int mouseX, int mouseY) const{
    return (mouseX >= x &&
            mouseX <= x + width &&
            mouseY >= y &&
            mouseY <= y + height);
}